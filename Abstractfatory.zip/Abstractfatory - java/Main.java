package Abstractfatory;

public class Main {
	
	public static void main (String [] args) {
	AbstractFactory fabrica1= FactoryProducer.getFactory(false);
	
	LineFactory line1= fabrica1.getLine("Dashed");
	line1.create();
	
	LineFactory line2= fabrica1.getLine("Solid");
	line2.create();
	
	AbstractFactory fabrica2=FactoryProducer.getFactory(true);
	
	LineFactory line3=fabrica2.getLine("Dashed");
	line3.create();
	
	LineFactory line4= fabrica2.getLine("Solid");
	line4.create();

}
}

