package Abstractfatory;

public class RoundedDashedLine implements LineFactory {

	@Override
	public void create() {
		System.out.println("Dentro do m�todo create da classe RoundedDashedLine");
		
	}

}
