package Abstractfatory;

import Abstractfatory.AbstractFactory;
import Abstractfatory.LineFactory1;
import  Abstractfatory.RoundedLineFactory;

public class FactoryProducer {
	public static AbstractFactory getFactory (boolean rounded) {
		if (rounded) {
			return new RoundedLineFactory();
		}else {
			return new LineFactory1();
		}
	}
}

