package Abstractfatory;

public class Solid implements LineFactory{

	@Override
	public void create() {
		System.out.println("Inside the draw methof of the Solid class");
		
	}

}
