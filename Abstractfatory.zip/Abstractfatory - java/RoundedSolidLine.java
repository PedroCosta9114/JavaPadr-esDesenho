package Abstractfatory;

public class RoundedSolidLine implements LineFactory {

	@Override
	public void create() {
		System.out.println("Dentro do m�todo draw da classe RoundedSolidLine");
		
	}

}
