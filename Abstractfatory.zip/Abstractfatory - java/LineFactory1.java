package Abstractfatory;

public class LineFactory1 extends AbstractFactory {

	@Override
	LineFactory getLine(String lineType) {
		if(lineType.equalsIgnoreCase("Dashed")) {
				return new Dashed();
	}else if (lineType.equalsIgnoreCase("Solid")) {
			return new Solid();
	}
		return null;
	}

}
