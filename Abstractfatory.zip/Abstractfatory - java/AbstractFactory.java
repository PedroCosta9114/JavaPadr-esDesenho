package Abstractfatory;

public abstract class AbstractFactory {
	abstract LineFactory getLine(String lineType);

}
