package Abstractfatory;

public class RoundedLineFactory extends AbstractFactory{

	@Override
	LineFactory getLine(String lineType) {
		if(lineType.equalsIgnoreCase("Dashed")) {
			return new RoundedDashedLine();
		}	else if (lineType.equalsIgnoreCase("Solid")) {
			return new RoundedSolidLine();
		}
		return null;
	}
	
	}


