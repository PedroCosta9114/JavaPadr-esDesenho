package Abstractfatory;

public interface LineFactory {
	void create(); 
	}


