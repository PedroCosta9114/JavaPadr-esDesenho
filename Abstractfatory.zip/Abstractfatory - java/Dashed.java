package Abstractfatory;

public class Dashed implements LineFactory{

	@Override
	public void create() {
		System.out.println("Inside the draw method of the Dashed class");
		
	}

}
