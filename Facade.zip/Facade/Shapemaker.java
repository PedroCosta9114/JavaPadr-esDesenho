package Facade;

public class Shapemaker {
	private Shape circle;
	private Shape rectangle;
	private Shape square;
	private Shape oval;
	
	public Shapemaker() {
		circle=new Circle();
		rectangle=new Rectangle();
		square=new Square();
		oval=new Oval();
	}

	public void drawCircle() {
		circle.draw();
	}

	public void drawRectangle() {
		rectangle.draw();
	}
	public void drawSquare() {
		square.draw();
	}
	public void drawOval() {
		oval.draw();
	}
}

