package FactoryMethod;

public class FactoryTest {
	public static void main (String [] args) {
			ShapeFactory minhaFabrica = new ShapeFactory();
		
			Shape circle = minhaFabrica.getShape("CIRCLE");
			
			circle.draw();
			
			Shape rectangle = minhaFabrica.getShape("RECTANGLE");
			
			rectangle.draw();
			
			Shape square = minhaFabrica.getShape("SQUARE");
			
			square.draw();
			
			Shape oval = minhaFabrica.getShape("OVAL");
			
			oval.draw();
		}
	}
