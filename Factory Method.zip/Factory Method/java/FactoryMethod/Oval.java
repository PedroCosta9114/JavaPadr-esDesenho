package FactoryMethod;

public class Oval implements Shape{

	@Override
	public void draw() {
		System.out.println("Dentro do Oval: m�todo draw()");
	}

}
