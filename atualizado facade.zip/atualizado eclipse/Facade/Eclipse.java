package Facade;

public class Eclipse implements Shape{

	@Override
	public void draw() {
		System.out.println("Eclipse- draw()");
		
	}

}
