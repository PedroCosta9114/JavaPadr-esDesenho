package Facade;

public class Oval implements Shape{

	@Override
	public void draw() {
		System.out.println("Oval - draw()");
		
	}

}
