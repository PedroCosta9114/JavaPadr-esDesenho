package Facade;

public interface Shape {
	void draw();
}
