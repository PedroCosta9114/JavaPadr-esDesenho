package Iterator;

public class NameRepository implements Container{
	public String names[]= {"Rui", "Hugo", "Jo�o", "Pedro"};

	@Override
	public iterator getIterator() {
		return new nameiterator();
		
	}

	private class nameiterator implements iterator {
		int index;
		
		@Override
		public boolean hasNext() {
			if(index < names.length) {
				return true;
			}else {
				return false;
			}
		}

		@Override
		public Object next() {
			if(this.hasNext()) {
				return names[index++];
			}
			return null;
		}
		
	}
	
}

