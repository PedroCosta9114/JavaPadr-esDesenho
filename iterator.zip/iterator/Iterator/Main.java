package Iterator;

public class Main {
	public static void main (String[] args) {
		NameRepository obj1 = new NameRepository ();
		
		for(iterator iter = obj1.getIterator(); iter.hasNext();) {
			
			String name = (String) iter.next();
			
			System.out.println("Name: " + name);
		}
	}
	
}


