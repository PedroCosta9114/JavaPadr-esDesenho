package Iterator;

public interface Container {
	public iterator getIterator();
}
