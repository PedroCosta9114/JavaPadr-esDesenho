package Iterator;

public interface iterator {
	public boolean hasNext();
	public Object next();
	
}
