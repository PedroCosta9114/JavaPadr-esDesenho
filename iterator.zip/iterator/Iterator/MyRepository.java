package Iterator;

public class MyRepository implements iterator{
	public String names[]= {"Rui", "Hugo", "Jo�o", "Pedro"};
	int index = 0;
	@Override
	public boolean hasNext() {
		if(index < names.length) {
			return true;
		}else {
			return false;
		}
	}
	@Override
	public Object next() {
		if(this.hasNext()) {
			int index = 0;
			return names[index++];
		}
		return null;
	}
}







	
	
